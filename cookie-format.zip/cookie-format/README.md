# Cookie format

A Pen created on CodePen.io. Original URL: [https://codepen.io/Vix-Aar/pen/QWedYeL](https://codepen.io/Vix-Aar/pen/QWedYeL).

